
require 'bundler'
Bundler.require


require_all 'lib'

Router.new.perform